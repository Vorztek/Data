#TP 6 - Extraire les valeurs

Babar = {"name": "Babar" , "type": "Éléphant", "born": 1931, "activity": "Roi"}

Babar.value()

#Or :

print(Babar.values())
