# TP 1 Imprimez les chiffres de 1 à 10

for i in range(1,11, 1):
    print(i)

