# TP 11 Tranche de liste
#Extraire Pangolin et Poireaux de la liste en une seule ligne de commande"

ingredients = ['Carotte', 'Pangolin', 'Poireaux', 'Epices']
new_ingredient = ingredients[1:3]

print(new_ingredient)