# TP 4 Extraire l'année de naissance de Babar

#def Babar():

Babar = {"name": "Babare" , "type": "Éléphant", "born": 1931, "activity": "Roi"}
print(Babar.get("born"))

#Autre test :
#Babar = {"name":"Babar","type":"Elephant","born": 1931,"activity" : "Roi"}
#print(Babar.get("activity"))

