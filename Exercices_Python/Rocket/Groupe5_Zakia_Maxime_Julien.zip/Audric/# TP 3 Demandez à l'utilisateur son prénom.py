# TP 3 Demandez à l'utilisateur son prénom

print("Ton prénom ?")
name = input()
print("Le nom de ce commercial est {} ".format(name))
