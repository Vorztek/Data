# TP5 Modifier l'année de naissance de Babar

babar = {"name":"Babar","type":"Elephant","born": 1931,"activity" : "Roi"}

babar2 = {"born": 1930}
babar.update(babar2)
print(babar)