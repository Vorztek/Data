# TP 8 Extaire le pangolin

animaux = ['girafe','tigre','singe','souris','pangolin']

animaux[-1]

#Or

print(animaux[-1])