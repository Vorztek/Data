#TP 10 Ajouter des éléments à une liste

ingredients = ['Carotte', 'Pangolin', 'Poireaux', 'Epices']
ingredients2 = ["Carotte","Pangolin","Poireaux"]

ingredients = ingredients + ingredients2
print(ingredients)