# TP 2 Imprimer les chiffres de 1 à 10 en utilisant une boucle while

compteur = 1
while compteur < 11:
    print(compteur)
    compteur +=1