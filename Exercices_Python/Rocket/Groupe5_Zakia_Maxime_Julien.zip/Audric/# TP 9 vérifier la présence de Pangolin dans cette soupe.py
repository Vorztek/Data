#TP 9 vérifier la présence de Pangolin dans cette soupe

ingredients = ["Carotte","Pangolin","Poireaux"]

if "Pangolin" in ingredients:
    print("Ne mange pas cette soupe")
else:
    print("Tu peux manger cette soupe")

