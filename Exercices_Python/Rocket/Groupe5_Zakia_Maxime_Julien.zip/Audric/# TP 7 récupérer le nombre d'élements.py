#TP 7 récupérer le nombre d'élements

Babar = {"name": "Babar" , "type": "Éléphant", "born": 1931, "activity": "Roi"}
print(len(Babar))